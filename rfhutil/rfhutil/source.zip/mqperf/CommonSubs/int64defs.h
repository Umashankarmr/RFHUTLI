#ifndef _CommonSubs_int64defs_h
#define _CommonSubs_int64defs_h

/*************************************************************/
/*                                                           */
/* int64_t and uint64_t                                      */
/* Define 64-bit integers on Windows, since Windows uses a   */
/* non-standard definition.                                  */
/*                                                           */
/*************************************************************/

#ifdef WIN32
typedef __int64 int64_t;
typedef unsigned __int64 uint64_t;
#endif

/**********************************************************/
/*                                                        */
/* FMT_I64                                                */
/* Definition of format characters for 64-bit integer.    */
/*                                                        */
/**********************************************************/
#ifdef WIN32
#define FMTI64		"%I64d"
#define FMTI64U		"%I64u"
#define FMTI64_66	"%6.6I64d"
#else
#define FMTI64		"%lld"
#define FMTI64U		"%llu"
#define FMTI64_66	"%6.6lld"
#endif

#endif
