#ifndef _CommonSubs_timesubs_h
#define _CommonSubs_timesubs_h

#ifndef WIN32
#include <sys/time.h>
#endif

/**********************************************************/
/* MY_TIME_T                                              */
/* The definition of this data type is platform specific. */
/**********************************************************/
#ifdef WIN32
typedef unsigned __int64 MY_TIME_T;
#else
typedef struct timeval MY_TIME_T;
#endif

void GetTime(MY_TIME_T *tv);
void clearTime(MY_TIME_T *time);
int64_t timeToMicroSecs(MY_TIME_T time);
int64_t DiffTime(MY_TIME_T start, MY_TIME_T end);
void formatTimeDiff(char * result, int64_t diff);
void performTimerCheck();
void formatTimeSecsNoColons(char * timeOut, time_t timeIn);
void formatTimeSecs(char * timeOut, time_t timeIn);
void formatTimeDiffSecs(char * result, int64_t time);
void InitializeTimer();
int getSecs(int time);
#endif
