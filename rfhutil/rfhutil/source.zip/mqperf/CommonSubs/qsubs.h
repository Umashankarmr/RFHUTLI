/********************************************************************/
/*                                                                  */
/*   qsubs.h - header file for qsubs.c                              */
/*                                                                  */
/********************************************************************/
#ifndef _CommonSubs_qsubs_h
#define _CommonSubs_qsubs_h

void checkerror(const char *mqcalltype, MQLONG compcode, MQLONG reason, const char *resource);
void connect2QM(char * qmname, PMQHCONN qm, PMQLONG cc, PMQLONG reason);
void clientConnect2QM(char * qmname, PMQHCONN qm, int *maxMsgLen, PMQLONG cc, PMQLONG reason);
void formatTime(char *timeOut, char *timeIn);
void issueReply(MQHCONN qm, MQLONG	report, int *uow, char * msgId, PUTPARMS * parms);
void translateMQMD(void * mqmd, int datalen);
int checkMQMD(void * mqmdPtr, int datalen);
int checkAndXlateMQMD(void * mqmdPtr, int length);
void setContext(MQMD2 * mqmd);
#endif
